﻿namespace UITracker
{
    internal class ErrorCode
    {
    }
}